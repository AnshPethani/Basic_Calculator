package com.example.baisc_calc;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView resulttv, solutiontv;
    MaterialButton btnc, btnopen, btnclose, btndiv, btnac, btnmul, btnmin, btnadd, btneq, btndec, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resulttv = findViewById(R.id.result_tv);
        solutiontv = findViewById(R.id.solution_tv);
        assignId(btn0, R.id.btn_0);
        assignId(btn1, R.id.btn_1);
        assignId(btn2, R.id.btn_2);
        assignId(btn3, R.id.btn_3);
        assignId(btn4, R.id.btn_4);
        assignId(btn5, R.id.btn_5);
        assignId(btn6, R.id.btn_6);
        assignId(btn7, R.id.btn_7);
        assignId(btn8, R.id.btn_8);
        assignId(btn9, R.id.btn_9);
        assignId(btnc, R.id.c_btn);
        assignId(btnopen, R.id.open_btn);
        assignId(btnclose, R.id.close_btn);
        assignId(btndiv, R.id.div_btn);
        assignId(btnmul, R.id.mul_btn);
        assignId(btnmin, R.id.min_btn);
        assignId(btnadd, R.id.add_btn);
        assignId(btneq, R.id.eq_btn);
        assignId(btndec, R.id.dec_btn);
        assignId(btnac, R.id.ac_btn);
    }

    void assignId(MaterialButton btn, int id) {
        btn = findViewById(id);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        MaterialButton button = (MaterialButton) v;
        String buttonText = button.getText().toString();
        String toCalc = solutiontv.getText().toString();

        if(buttonText.equals("AC")){
            solutiontv.setText("0");
            resulttv.setText("0");
            return;
        }

        if (buttonText.equals("=")){
            solutiontv.setText(resulttv.getText());
            return;
        }

        if(buttonText.equals("C")){
            toCalc = toCalc.substring(0,toCalc.length()-1);
            return;
        }
        else {
            toCalc = toCalc + buttonText;
        }
        solutiontv.setText(toCalc);
        String finalres = getAns(toCalc);
        if(!finalres.equals("Err")) {
            resulttv.setText(finalres);
        }
        }

        String getAns(String data){
        try {
            Context c = Context.enter();
            c.setOptimizationLevel(-1);
            Scriptable s = c.initStandardObjects();
            String calc = c.evaluateString(s, data, "Javacript", 1, null).toString();
            if (calc.endsWith(".0")) {
                calc = calc.replace(".0", "");
            }
            return calc;
        }
        catch(Exception e){
            return "Err";
        }
        }
}